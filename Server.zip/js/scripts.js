//The below function opens and fills the location info pop-up (modal) with data for each location
function openModal() {
  $("area").each(function (i) {
    $(this).click(function (e) {
      e.preventDefault();
      $("#modal").hide();
      var id = $(this).attr("id");
      $.ajax({
        url: `http://localhost:3000/area?id=${id}`,
        success: function (data) {
          $(
            "#modal .title h2, #modal div.score, #modal p.description, #modal ul.comments"
          ).html("");
          $("#modal .title h2").html(data.placeName);
          $("#modal div.score").html("Average Score: " + data.score.average);
          $("#modal p.description").html(data.placeDescription);
          $("#modal button.openform").attr("data-id", id); //the button operates the openform function which takes a location id as a parameter, so we pass the appropriate id in here
          data.opinions.forEach(function (opinion) {
            $("#modal ul.comments").append(
              "<li><p>" +
                opinion.comments +
                '</p><p class="signature">' +
                opinion.userName +
                "</p></li>"
            ); //format how the specific part to each comment are displayed with the appropriate data
          });
          $("#modal").show(100);
          openForm(data);
        },
      });
    });
  });
}

function closeModal() {
  $("#modal .close").click(function (e) {
    e.preventDefault();
    $("#modal").hide(100);
  });
}

function openForm(data) {
  $("#modal button.openform").click(function () {
    $("#modal").css({ top: "0.3%" });
    $("#modal .info").hide();
    $("#modal form h2 span").html(data.placeName);
    $("#modal form input[name='id']").val(data.id);
    $("#modal form").show();
  });
}

function menu() {
  var acc = document.getElementsByClassName("accordion");
  var i;

  for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function () {
      /* Toggle between adding and removing the "active" class,
    to highlight the button that controls the panel */
      this.classList.toggle("active");

      /* Toggle between hiding and showing the active panel */
      var panel = this.nextElementSibling;
      if (panel.style.display === "block") {
        panel.style.display = "none";
      } else {
        panel.style.display = "block";
      }
    });
  }
}
openModal();
closeModal();
menu();

function submitForm() {
  $("#submitForm").ajaxSubmit(function (message) {
    // console.log(decodeURI("传回数据："+message));
    alert("commit success");
  });
  window.close();
  return false;
}
