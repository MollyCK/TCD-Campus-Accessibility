/*
 Navicat Premium Data Transfer

 Source Server         : ECSMongodb
 Source Server Type    : MongoDB
 Source Server Version : 40401
 Source Host           : 123.56.68.67:7017
 Source Schema         : School

 Target Server Type    : MongoDB
 Target Server Version : 40401
 File Encoding         : 65001

 Date: 09/04/2021 16:00:38
*/


// ----------------------------
// Collection structure for Area
// ----------------------------
db.getCollection("Area").drop();
db.createCollection("Area");

// ----------------------------
// Documents of Area
// ----------------------------
db.getCollection("Area").insert([ {
    _id: ObjectId("606fc2659f1dba3e74002dbd"),
    id: NumberInt("75"),
    placeName: "Arts Block",
    placeDescription: "Description Bla bla bla",
    score: {
        people: NumberInt("1"),
        movement: NumberInt("4"),
        talking: NumberInt("2"),
        noise: NumberInt("3"),
        noiseType: "Voices",
        light: NumberInt("2"),
        lightBright: NumberInt("1"),
        lightFlickering: NumberInt("2"),
        lightColourPeculiar: NumberInt("4"),
        smells: NumberInt("4"),
        smellType: "Food",
        floorSticky: NumberInt("1"),
        floorUneven: NumberInt("1"),
        seatsHard: NumberInt("4"),
        texturesRough: NumberInt("4"),
        average: 2.3
    },
    opinions: [
        {
            userName: "Patrick O'Flanagan",
            score: {
                people: NumberInt("1"),
                movement: NumberInt("4"),
                talking: NumberInt("2"),
                noise: NumberInt("3"),
                noiseType: "Voices",
                light: NumberInt("2"),
                lightBright: NumberInt("1"),
                lightFlickering: NumberInt("2"),
                lightColourPeculiar: NumberInt("4"),
                smells: NumberInt("4"),
                smellType: "Food",
                floorSticky: NumberInt("1"),
                floorUneven: NumberInt("1"),
                seatsHard: NumberInt("4"),
                texturesRough: NumberInt("4")
            },
            comments: "Comment 1 Bla bla bla bla"
        },
        {
            userName: "Fiona Gallagher",
            score: {
                people: NumberInt("1"),
                movement: NumberInt("4"),
                talking: NumberInt("2"),
                noise: NumberInt("3"),
                noiseType: "Voices",
                light: NumberInt("2"),
                lightBright: NumberInt("1"),
                lightFlickering: NumberInt("2"),
                lightColourPeculiar: NumberInt("4"),
                smells: NumberInt("4"),
                smellType: "Food",
                floorSticky: NumberInt("1"),
                floorUneven: NumberInt("1"),
                seatsHard: NumberInt("4"),
                texturesRough: NumberInt("4")
            },
            comments: "Comment 2 Bla bla bla bla"
        },
        {
            userName: "222",
            comments: "ccc",
            score: {
                id: "75",
                people: "1",
                movement: "1",
                talking: "1",
                noise: "1",
                light: "1",
                lightBright: "1",
                lightFlickering: "1",
                lightColourPeculiar: "1",
                smells: "1",
                floorSticky: "1",
                floorUneven: "1",
                seatsHard: "1",
                texturesRough: "1"
            }
        },
        {
            userName: "222",
            comments: "ccc",
            score: {
                id: "75",
                people: "1",
                movement: "1",
                talking: "1",
                noise: "1",
                light: "1",
                lightBright: "1",
                lightFlickering: "1",
                lightColourPeculiar: "1",
                smells: "1",
                floorSticky: "1",
                floorUneven: "1",
                seatsHard: "1",
                texturesRough: "1"
            }
        },
        {
            userName: "222",
            comments: "ccc",
            score: {
                id: "75",
                people: "1",
                movement: "1",
                talking: "1",
                noise: "1",
                light: "1",
                lightBright: "1",
                lightFlickering: "1",
                lightColourPeculiar: "1",
                smells: "1",
                floorSticky: "1",
                floorUneven: "1",
                seatsHard: "1",
                texturesRough: "1"
            }
        },
        {
            userName: "",
            comments: "cscs",
            score: {
                id: "75",
                people: "1",
                movement: "1",
                talking: "1",
                noise: "1",
                light: "1",
                lightBright: "1",
                lightFlickering: "1",
                lightColourPeculiar: "1",
                smells: "1",
                floorSticky: "1",
                floorUneven: "1",
                seatsHard: "1",
                texturesRough: "1"
            }
        },
        {
            userName: "",
            comments: "cscs",
            score: {
                id: "75",
                people: "1",
                movement: "1",
                talking: "1",
                noise: "1",
                light: "1",
                lightBright: "1",
                lightFlickering: "1",
                lightColourPeculiar: "1",
                smells: "1",
                floorSticky: "1",
                floorUneven: "1",
                seatsHard: "1",
                texturesRough: "1"
            }
        },
        {
            userName: "",
            comments: "cscs",
            score: {
                id: "75",
                people: "1",
                movement: "1",
                talking: "1",
                noise: "1",
                light: "1",
                lightBright: "1",
                lightFlickering: "1",
                lightColourPeculiar: "1",
                smells: "1",
                floorSticky: "1",
                floorUneven: "1",
                seatsHard: "1",
                texturesRough: "1"
            }
        },
        {
            userName: "",
            comments: "",
            score: {
                id: "75",
                people: "1",
                movement: "1",
                talking: "1",
                noise: "1",
                light: "1",
                lightBright: "1",
                lightFlickering: "1",
                lightColourPeculiar: "1",
                smells: "1",
                floorSticky: "1",
                floorUneven: "1",
                seatsHard: "1",
                texturesRough: "1"
            }
        },
        {
            userName: "",
            comments: "测试",
            score: {
                id: "75",
                people: "1",
                movement: "1",
                talking: "1",
                noise: "1",
                light: "1",
                lightBright: "1",
                lightFlickering: "1",
                lightColourPeculiar: "1",
                smells: "1",
                floorSticky: "1",
                floorUneven: "1",
                seatsHard: "1",
                texturesRough: "1"
            }
        }
    ]
} ]);
