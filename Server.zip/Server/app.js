
const fastify = require("fastify")({
  logger: true,
});
// const MongoClient = require("mongodb").MongoClient;
//let url = "mongodb://localhost:27017";
let url = "mongodb://admin:pkjs123456@123.56.68.67:7017";
const dbName = "School";
const { corsHandler } = require("./corsHandler");

fastify.register(require("fastify-mongodb"), {
  // force to close the mongodb connection when app stopped
  // the default value is false
  forceClose: true,
  url: url,
});
fastify.register(require("fastify-formbody"));

//get port
fastify.get("/area", function (req, reply) {
  // Or this.mongo.client.db('mydb')
  const db = this.mongo.client.db(dbName);
  db.collection("Area", onCollection);
  function onCollection(err, col) {
    if (err) return reply.send(err);
    var areaId = parseInt(req.query.id);
    col.findOne({ id: areaId }, (err, data) => {
      reply.send(data);
    });
  }
});
//submit port
fastify.post("/addComment", function (req, reply) {
  // Or this.mongo.client.db('mydb')
  const db = this.mongo.client.db(dbName);
  db.collection("Area", onCollection);
  function onCollection(err, col) {
    if (err) return reply.send(err);
    //get and update//
    var areaId = parseInt(req.body.id);
    col.findOne({ id: areaId }, (err, data) => {
      //get data
      let opinion = {};
      let area = {};
      opinion.userName = req.body.userName;
      opinion.comments = req.body.comments;
      opinion.score = req.body;
      delete opinion.score.userName;
      delete opinion.score.comments;
      data.opinions.push(opinion);
      area = data;
      col.remove({ id: areaId }, (err, data) => {
        col.insert(area, (err, data) => {
          if (err) return reply.send(err);
          reply.send(data);
        });
      });
      //adding data
      //db.col.update({'title':'MongoDB tut'},{$set:{'title':'MongoDB'}})
    });
  }
});
fastify.addHook("onRequest", async (request, reply) => {
  await corsHandler(request, reply);
});
// start server!
fastify.listen(3000, function (err, address) {
  if (err) {
    fastify.log.error(err);
    process.exit(1);
  }
  fastify.log.info(`server listening on ${address}`);
});
