/* eslint-disable */
exports.corsHandler = async (
  { headers: { origin = "" }, raw: { method } },
  reply
) => {
  console.log(method);
  console.log("get request CorsHandler");
  // if (origin) {
  //   if (config.allowOrigins.includes(origin)) {
  //     reply.header('Access-Control-Allow-Origin', origin);
  //   } else {
  //     reply.code(404).send({ message: 'not allowed using api' });
  //   }
  // }
  reply.header("Access-Control-Allow-Origin", "*");
  reply.header(
    "Access-Control-Allow-Headers",
    "Authorization, Origin, No-Cache, X-Requested-With, If-Modified-Since, Pragma, Last-Modified, Cache-Control, Expires, Content-Type, X-E4M-With"
  );
  reply.header(
    "Access-Control-Allow-Methods",
    "PUT,PATCH,POST,GET,DELETE,OPTIONS"
  );
  // OPTIONS
  if (method === "OPTIONS") {
    return reply.code(200).send();
  }
};
